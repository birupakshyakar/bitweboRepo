free-educational-responsive-web-template-webEdu
-------

Web Edu is an education theme with an elegant look and feel, designed to meet the needs of Schools, Colleges, Institutes, eLearning Centers and Universities. This template is Responsive and built using HTML5 Bootstrap framework, It�s provided with an nice responsive layer slider. This theme is very easy to customize asper you requirments.

 
Features :
--------
=> Twitter Bootstrap 3.2.0
=> Clean & Developer-friendly HTML5 and CSS3 code
=> 100% Responsive Layout Design
=> Multipurpose theme
=> Google Fonts Support
=> Font Awesome
=> Gallery Section Lightbox
=> Smooth Scrolling
=> Fully Customizable
=> Camera Carousal

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com 
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> Image: All the images are used for DEMO purous only. we are not responsible for copyrights issues.
=> https://www.flickr.com/photos/vancouverfilmschool/

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/
**Note: Please dont remove the backlink (Template by: webthemez.com) in the footer.
